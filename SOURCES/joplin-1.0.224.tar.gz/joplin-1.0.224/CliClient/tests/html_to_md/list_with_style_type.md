1.  Item A
2.  Item B
3.  Item C