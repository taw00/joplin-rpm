Sometimes Evernote wraps lines inside blocks
Sometimes it doesn't wrap them
But
careful
with
pre tags