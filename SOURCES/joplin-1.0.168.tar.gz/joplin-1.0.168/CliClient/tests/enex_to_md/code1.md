For example, consider a web page like this:

	<!DOCTYPE html>
	<html>
	  <head>
	    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
	  </head>

	  <body>
	    <script src="page-scripts/page-script.js"></script>
	  </body>
	</html>

The script "page-script.js" does this: