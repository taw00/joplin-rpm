main app is missing highcontrast icons. I created them here. Will be submitted later.
