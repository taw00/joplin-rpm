The upstream app is missing highcontrast icons. I created them here. Will be submitted later.

UPDATE: Upstream rejected the icons for now (he doesn't want to maintain them).

The RPM should place these in...
```
/usr/share/icons/HighContrast/NNNxNNN/apps/org.joplinapp.Joplin.png
```

Flatpaks place these in...
```
/app/share/icons/HighContrast/NNNxNNN/apps/org.joplinapp.Joplin.png
```

