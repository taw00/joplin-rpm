**singleline bold text with span style font-weight: bold;.**

**singleline bold text with span style font-family: 'TimesNewRoman,Bold';.**

**multiline bold text with span style font-weight: bold;.**

**multiline bold text with span style font-family: 'TimesNewRoman,Bold';.**

**singleline bold text with span style font-weight: bold;** next to normal text with leading space.

**singleline bold text with span style font-weight: bold; and with trailing space **next to normal text.

**singleline bold text with span style font-weight: bold;**** next to more bold text with span style font-weight: bold; and with leading space.**

**singleline bold text with span style font-weight: bold; and with trailing space ****next to more bold text with span style font-weight: bold;.**