<style>
  .different h5 { color: lightgreen; }
  h5 { color: orange; }
  h6 { color: orange; }
  .different h6 { color: lightgreen; }
</style>