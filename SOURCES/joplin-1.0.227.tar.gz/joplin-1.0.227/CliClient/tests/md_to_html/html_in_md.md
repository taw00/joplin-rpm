Line 1
<div>Line 2</div>
<div><span>Line</span> 4</div>
Line 5