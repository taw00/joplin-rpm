|     |     |
| --- | --- |
| Something that was originally spanning two columns |     |
| One | Two |