package net.cozic.joplin.share;


// import ReactActivity
import com.facebook.react.ReactActivity;


public class ShareActivity extends ReactActivity {
		@Override
		protected String getMainComponentName() {
			// this is the name AppRegistry will use to launch the Share View
			return "Joplin";
		}
}

