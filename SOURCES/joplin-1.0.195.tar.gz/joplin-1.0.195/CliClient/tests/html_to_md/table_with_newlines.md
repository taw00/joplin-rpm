|     |     |
| --- | --- |
| Some paragraph<br><br>inside a table cell | Second column |