<style>
.md-checkbox input[type="checkbox"]:not(:checked),
.md-checkbox input[type="checkbox"]:not(:checked)+label {
    display:none;
}
</style>