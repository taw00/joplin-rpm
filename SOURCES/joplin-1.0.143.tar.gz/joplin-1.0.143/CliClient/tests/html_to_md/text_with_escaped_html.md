Some text, not an image, so it should remain escaped:

&lt;img src="http://test.com/image.png" /&gt;

&lt;p class="testing"&gt;Paragraph example&lt;/p&gt;

But this is code so it can be unescaped:

    <img src="http://test.com/image.png" />