**singleline strong text.**

**singleline bold text.**

**multiline strong text.**

**multiline bold text.**

*singleline emphasized text.*

*singleline italic text.*

*multiline emphasized text.*

*multiline italic text.*

**singleline bold text** next to normal text with leading space.

**singleline bold text with trailing space **next to normal text.

**singleline bold text**** next to more bold text with leading space.**

**singleline bold text with trailing space ****next to more bold text.**