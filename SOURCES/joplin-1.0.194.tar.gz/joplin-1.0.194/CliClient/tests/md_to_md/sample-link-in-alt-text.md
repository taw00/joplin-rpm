# Markdown
![../support/photo.jpg](../support/photo.jpg) should put resource link inside () not []
![../support/photo.jpg](     ../support/photo.jpg   ) this case (spaces before/after link but within parens) is not currently covered
