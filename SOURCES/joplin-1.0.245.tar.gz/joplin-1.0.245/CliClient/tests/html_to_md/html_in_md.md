Line 1

<div>Line 2</div><div><span>Line</span> 4</div>

Line 5

Line 6

<div>Markdown **inside**</div>