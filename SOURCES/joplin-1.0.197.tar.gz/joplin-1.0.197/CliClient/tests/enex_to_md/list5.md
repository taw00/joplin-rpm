- Protocols

    - two common network protocols used to send data packets over a network

    - TCP Transmission control protocol

- Network port - a network port is a process-specific or an application-specific software construct serving as a communication endpoint, which is used by the Transport Layer protocols of Internet Protocol suite, such as UDP and TCP