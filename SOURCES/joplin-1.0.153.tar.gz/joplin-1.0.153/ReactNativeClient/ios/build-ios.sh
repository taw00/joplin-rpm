#!/bin/bash
xcodebuild -project Joplin.xcodeproj -configuration Release -scheme Joplin -destination id=3AF6C788-B6ED-41DD-85F0-32D719DB0DBE -derivedDataPath build
