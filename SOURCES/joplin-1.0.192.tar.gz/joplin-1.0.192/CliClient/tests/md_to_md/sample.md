# Markdown

lorem ipsum ![alt text here](../support/photo.jpg)
- [ ] check!
- [ ] boxes!

![alt text here](../support/photo-two.jpg)ipsum lorem

**strong text**
![does not exist](does_not_exist.png) lorem ipsum

**some directory**
![a directory](../support) lorem ipsum
