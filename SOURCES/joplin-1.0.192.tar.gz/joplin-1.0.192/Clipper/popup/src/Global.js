const Global = {};

Global.browser = function() {
	return window.browser;
};

module.exports = Global;
