- (git) tools suggestion / referencing
- coding style
- quick introduction, 3 steps to contribute / apply for GSoC 
- show prove of improvment
- 

 
