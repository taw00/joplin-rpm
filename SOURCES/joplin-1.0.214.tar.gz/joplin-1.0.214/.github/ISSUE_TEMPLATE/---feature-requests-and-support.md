---
name: "\U0001F914 Feature requests and support"
about: 'For non-bug issues we recommend using the forum, where you''ll be more likely
  to get an answer: https://discourse.joplinapp.org/'
title: ''
labels: ''
assignees: ''

---

If this is a feature request or a support query, please note that you'll not get an answer here.

Instead we recommend using the forum where you'll are a lot more likely to get an answer: https://discourse.joplinapp.org/

The forum is also the right place to submit a feature request so that it can be discussed by other users.
