*singleline italic text with span style font-style: italic;.*

*multiline italic text with span style font-style: italic;.*

*singleline italic text with span style font-style: italic;* next to normal text with leading space.

*singleline italic text with span style font-style: italic; and with trailing space *next to normal text.

*singleline italic text with span style font-style: italic;** next to more italic text with span style font-style: italic; and with leading space.*

*singleline italic text with span style font-style: italic; and with trailing space **next to more italic text with span style font-style: italic;.*