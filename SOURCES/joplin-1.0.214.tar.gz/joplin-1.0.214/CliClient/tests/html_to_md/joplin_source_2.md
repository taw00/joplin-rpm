$$
katexcode
$$