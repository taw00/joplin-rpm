#!/bin/bash
npm start -- --reset-cache