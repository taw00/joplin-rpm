<img src="https://joplin.cozic.net/images/DemoDesktop.png" style="max-width: 100%">

For general information relevant to all the applications, see also [Joplin home page](https://joplin.cozic.net).