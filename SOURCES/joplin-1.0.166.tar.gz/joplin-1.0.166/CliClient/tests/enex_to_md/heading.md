Values added to the global scope of a content script with

## Loading content scripts

You can load a content script into a web page in one of three ways: