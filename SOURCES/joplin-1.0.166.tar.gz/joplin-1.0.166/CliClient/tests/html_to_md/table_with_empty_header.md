|     |     |
| --- | --- |
| **Official Things** |     |
| [Web Site](https://nim-lang.org) | The project’s entry point |
| [Source](https://github.com/nim-lang/nim) | The github project |
| [nimble](https://github.com/nim-lang/nimble) | The nim package manager |
| [choosenim](https://github.com/dom96/choosenim) | Toolchain installer |
| **Community** |     |
| [Forums](https://forum.nim-lang.org) | An async discussion board |