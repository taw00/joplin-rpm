const { main } = require('./main.js');

main();
