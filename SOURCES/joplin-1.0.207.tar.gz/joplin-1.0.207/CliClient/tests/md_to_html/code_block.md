```javascript
function() {
    console.info('bonjour');
}
```