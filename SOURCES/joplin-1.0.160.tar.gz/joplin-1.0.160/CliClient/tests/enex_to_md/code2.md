Subshell:

	(
	    set -e
	    false
	    echo Unreachable
	) && echo Great success