    def ma_fonction():
        """
            C'est une super fonction
        """
        pass