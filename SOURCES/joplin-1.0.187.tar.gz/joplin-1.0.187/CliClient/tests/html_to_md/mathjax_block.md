_Block formulas_ are surrounded by double dollar signs. For example, `$$x = \frac{-b \pm \sqrt{b^2 - 4ac} }{2a}$$` renders, _on a separate line_, as

$$
x = \frac{-b \pm \sqrt{b^2 - 4ac} }{2a}.
$$