/* eslint-disable no-unused-vars, @typescript-eslint/no-unused-vars */

// Add here all the external scripts that the content script might need
// and run browserify on it to create vendor.bundle.js
const Readability = require('readability-node').Readability;
