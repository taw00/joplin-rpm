# GSoC: Tag handling

- [Feature Request: Tags on whole markdown lines #1498](https://github.com/laurent22/joplin/issues/1498)
- [Feature Request: Option to have a space for tags after the title #1399](https://github.com/laurent22/joplin/issues/1399)
- [Feature request: set @tags from markdown editor #1407](https://github.com/laurent22/joplin/issues/1407)
- [So many tags #1221](https://github.com/laurent22/joplin/issues/1221)
- [Organize and share using Turtl’s Spaces.](https://turtlapp.com/features/)

“[Feature Request] Tags on whole markdown lines #1498”: I prefer we remove this as this too far from standard markdown.

“Feature request: set @tags from markdown editor #1407”. I prefer if we remove this too for the same reason. I think tagging is already easy since there’s a keyboard shortcut for it. Maybe back then there wasn’t.

“So many tags #1221”: Was a bug, which has been fixed.

