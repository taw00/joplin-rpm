This is the language packs for TinyMCE.

- Get the packs from there: https://www.tiny.cloud/get-tiny/language-packages/
- Then they need to be copied to the node_modules/tinymce directory. This is done from the ElectronClient gulpfile.