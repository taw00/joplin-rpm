*Block formulas* are surrounded by double dollar signs. For example, `$$x = \frac{-b \pm \sqrt{b^2 - 4ac} }{2a}$$` renders, *on a separate line*, as

$$
x = \frac{-b \pm \sqrt{b^2 - 4ac} }{2a}.
$$