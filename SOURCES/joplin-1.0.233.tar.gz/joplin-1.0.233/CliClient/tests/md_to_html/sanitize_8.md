```html
<a href="#" onclick="leavethisalone">testing fence</a>
```
