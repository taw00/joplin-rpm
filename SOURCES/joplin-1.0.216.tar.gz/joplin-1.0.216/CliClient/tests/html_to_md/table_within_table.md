First column, and an inner table:

|     |     |
| --- | --- |
| One | Two |
| One | Two |

Second column