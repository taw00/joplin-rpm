```
thatsCode();
```

thatsJustPre(); // In that case we do not have enough info to know if it is a codeblock or not, so we leave it as plain text