### Operating system

<!-- Please only leave those relevant to your request -->

- Windows
- macOS
- Linux
- Android
- iOS

### Application

<!-- Please only leave those relevant to your request -->

- Desktop
- Mobile
- Terminal

<!--
Please read the guide first! https://github.com/laurent22/joplin/blob/master/CONTRIBUTING.md

If you are reporting a bug, did you try enabling debug mode? https://joplinapp.org/debugging/
If so, please post any error or warning.

For general discussion, user support or to discuss feature requests, please post to the forum https://discourse.joplinapp.org/ (You can login with your GitHub account)
-->
