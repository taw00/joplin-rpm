<img src="https://joplinapp.org/images/DemoDesktop.png" style="max-width: 100%">

For general information relevant to all the applications, see also [Joplin home page](https://joplinapp.org).