# Nextcloud App

**This is a beta feature, not yet completed. More info coming soon!**

The Joplin Nextcloud App is a helper application that enables certain features that are not possible otherwise. In particular:

- [Done] Sharing a note publicly
- [Not done] Sharing a note with another Joplin user (who uses the same Nextcloud instance)
- [Not done] Collaborating on a note
- [Not done] Sharing a notebook