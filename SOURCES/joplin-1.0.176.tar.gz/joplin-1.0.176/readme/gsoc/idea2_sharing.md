# GSoC: Sharing

- [Feature Request: Multiple note directories #108](https://github.com/laurent22/joplin/issues/108)
- [Feature Request: Note Sharing #1085](https://github.com/laurent22/joplin/issues/1085)
- [Feature Request: Multiple synchronization targets #1293](https://github.com/laurent22/joplin/issues/1293)
- [Please give the ability to share from another Android app into Joplin. #110](https://github.com/laurent22/joplin/issues/110)
- [Mobile - Add share menu #876](https://github.com/laurent22/joplin/issues/876)
- [Turtl’s sharing - Choose who you share with and what they can do.](https://turtlapp.com/features/)
- [Turtl Documentation - App architecture](https://turtlapp.com/docs/architecture)

"Please give the ability to share from another Android app into Joplin": This is already done
