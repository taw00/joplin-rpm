# GSoC: Search engine improvements

[Search engine improvements](https://github.com/laurent22/joplin/issues/1877)
